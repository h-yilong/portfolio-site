export type GameState = "menu" | "playing" | "paused" | "gameOver";

export type Direction = "up" | "down" | "left" | "right";

export type TileType = "empty" | "wall" | "breakable" | "bomb" | "explosion" | "powerup";

export interface Position {
  x: number;
  y: number;
}

export interface Tile {
  type: TileType;
  x: number;
  y: number;
  breakable?: boolean;
  powerupType?: "bomb" | "range" | "speed";
}

export interface Player {
  id: string;
  x: number;
  y: number;
  direction: Direction;
  bombs: number;
  maxBombs: number;
  bombRange: number;
  speed: number;
  isAlive: boolean;
  lastMoveTime: number;
}

export interface Bomb {
  id: string;
  x: number;
  y: number;
  timer: number;
  range: number;
  owner: string;
  placedTime: number;
}

export interface Explosion {
  id: string;
  x: number;
  y: number;
  timer: number;
  range: number;
  direction: Direction | "center";
}

export interface PowerUp {
  id: string;
  x: number;
  y: number;
  type: "bomb" | "range" | "speed";
}

export interface GameConfig {
  canvasWidth: number;
  canvasHeight: number;
  tileSize: number;
  playerSpeed: number;
  bombTimer: number;
  explosionTimer: number;
  powerUpChance: number;
}

export interface GameCallbacks {
  onStateChange: (state: GameState) => void;
  onScoreChange: (score: number) => void;
}

export interface InputState {
  up: boolean;
  down: boolean;
  left: boolean;
  right: boolean;
  space: boolean;
}
