# Bomberman Game

一个使用HTML5 Canvas和TypeScript实现的经典Bomberman游戏。

## 游戏特性

- 🎮 经典Bomberman玩法
- 🎨 现代化的UI设计
- ⚡ 性能优化的游戏引擎
- 🎯 随机地图生成
- 💎 道具系统（炸弹数量、爆炸范围、移动速度）
- 🎵 流畅的动画效果

## 控制方式

- **方向键** 或 **WASD**: 移动角色
- **空格键**: 放置炸弹
- **P键**: 暂停/恢复游戏
- **R键**: 重新开始游戏

## 游戏规则

1. 使用炸弹炸开可破坏的墙壁
2. 收集道具来增强能力：
   - 💣 炸弹道具：增加可同时放置的炸弹数量
   - 🔥 范围道具：增加炸弹爆炸范围
   - ⚡ 速度道具：增加移动速度
3. 避免被爆炸波及
4. 尽可能获得高分

## 技术实现

### 性能优化

- **对象池**: 减少垃圾回收，提高性能
- **Canvas优化**: 使用`imageSmoothingEnabled = false`提高渲染性能
- **游戏循环**: 使用`requestAnimationFrame`确保60fps
- **碰撞检测**: 高效的碰撞检测算法

### 架构设计

- **模块化**: 每个功能都有独立的类
- **类型安全**: 完整的TypeScript类型定义
- **可扩展**: 易于添加新功能

### 文件结构

```
src/app/games/bomberman/
├── page.tsx          # 主页面组件
├── GameEngine.ts     # 游戏引擎核心
├── MapGenerator.ts   # 地图生成器
├── Renderer.ts       # 渲染器
├── InputManager.ts   # 输入管理器
├── CollisionManager.ts # 碰撞检测
├── ObjectPool.ts     # 对象池（性能优化）
├── types.ts          # 类型定义
└── README.md         # 说明文档
```

## 访问游戏

启动开发服务器后，访问：`http://localhost:8765/games/bomberman`

## 未来扩展

- [ ] 多人游戏支持
- [ ] 音效和背景音乐
- [ ] 更多道具类型
- [ ] 关卡系统
- [ ] 成就系统
- [ ] 排行榜
