"use client";

import { useEffect, useState } from "react";

interface PerformanceMonitorProps {
  isActive: boolean;
}

export function PerformanceMonitor({ isActive }: PerformanceMonitorProps) {
  const [fps, setFps] = useState(0);
  const [frameTime, setFrameTime] = useState(0);
  const [memoryUsage, setMemoryUsage] = useState<number | null>(null);

  useEffect(() => {
    if (!isActive) return;

    let frameCount = 0;
    let lastTime = performance.now();
    let lastFpsUpdate = performance.now();

    const updateFPS = () => {
      const currentTime = performance.now();
      frameCount++;

      // 每秒更新一次FPS
      if (currentTime - lastFpsUpdate >= 1000) {
        const currentFps = Math.round((frameCount * 1000) / (currentTime - lastFpsUpdate));
        setFps(currentFps);
        frameCount = 0;
        lastFpsUpdate = currentTime;
      }

      // 计算帧时间
      const deltaTime = currentTime - lastTime;
      setFrameTime(Math.round(deltaTime));
      lastTime = currentTime;

      // 获取内存使用情况（如果可用）
      if ("memory" in performance) {
        const memory = (performance as any).memory;
        setMemoryUsage(Math.round(memory.usedJSHeapSize / 1024 / 1024)); // MB
      }

      requestAnimationFrame(updateFPS);
    };

    const animationId = requestAnimationFrame(updateFPS);

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, [isActive]);

  if (!isActive) return null;

  return (
    <div className="bg-opacity-75 fixed top-20 right-4 z-10 rounded-lg bg-black p-3 font-mono text-sm text-white">
      <div className="space-y-1">
        <div className="flex justify-between">
          <span>FPS:</span>
          <span className={fps >= 55 ? "text-green-400" : fps >= 30 ? "text-yellow-400" : "text-red-400"}>{fps}</span>
        </div>
        <div className="flex justify-between">
          <span>Frame:</span>
          <span className={frameTime <= 16.67 ? "text-green-400" : "text-yellow-400"}>{frameTime}ms</span>
        </div>
        {memoryUsage !== null && (
          <div className="flex justify-between">
            <span>Memory:</span>
            <span>{memoryUsage}MB</span>
          </div>
        )}
      </div>
    </div>
  );
}
