import { InputState } from "./types";

export class InputManager {
  private inputState: InputState = {
    up: false,
    down: false,
    left: false,
    right: false,
    space: false,
  };

  private keyHandlers: Map<string, () => void> = new Map();
  private isInitialized = false;

  public init(): void {
    if (this.isInitialized) return;

    this.setupEventListeners();
    this.isInitialized = true;
  }

  public destroy(): void {
    if (!this.isInitialized) return;

    this.removeEventListeners();
    this.isInitialized = false;
  }

  public getInput(): InputState {
    return { ...this.inputState };
  }

  private setupEventListeners(): void {
    // Key down events
    document.addEventListener("keydown", this.handleKeyDown.bind(this));

    // Key up events
    document.addEventListener("keyup", this.handleKeyUp.bind(this));

    // Prevent default behavior for game keys
    document.addEventListener("keydown", this.preventDefaultForGameKeys.bind(this));

    // Handle window blur to reset input state
    window.addEventListener("blur", this.resetInputState.bind(this));
  }

  private removeEventListeners(): void {
    document.removeEventListener("keydown", this.handleKeyDown.bind(this));
    document.removeEventListener("keyup", this.handleKeyUp.bind(this));
    document.removeEventListener("keydown", this.preventDefaultForGameKeys.bind(this));
    window.removeEventListener("blur", this.resetInputState.bind(this));
  }

  private handleKeyDown(event: KeyboardEvent): void {
    switch (event.code) {
      case "ArrowUp":
      case "KeyW":
        this.inputState.up = true;
        break;
      case "ArrowDown":
      case "KeyS":
        this.inputState.down = true;
        break;
      case "ArrowLeft":
      case "KeyA":
        this.inputState.left = true;
        break;
      case "ArrowRight":
      case "KeyD":
        this.inputState.right = true;
        break;
      case "Space":
        this.inputState.space = true;
        break;
    }
  }

  private handleKeyUp(event: KeyboardEvent): void {
    switch (event.code) {
      case "ArrowUp":
      case "KeyW":
        this.inputState.up = false;
        break;
      case "ArrowDown":
      case "KeyS":
        this.inputState.down = false;
        break;
      case "ArrowLeft":
      case "KeyA":
        this.inputState.left = false;
        break;
      case "ArrowRight":
      case "KeyD":
        this.inputState.right = false;
        break;
      case "Space":
        this.inputState.space = false;
        break;
    }
  }

  private preventDefaultForGameKeys(event: KeyboardEvent): void {
    const gameKeys = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "KeyW", "KeyA", "KeyS", "KeyD", "Space"];

    if (gameKeys.includes(event.code)) {
      event.preventDefault();
    }
  }

  private resetInputState(): void {
    this.inputState = {
      up: false,
      down: false,
      left: false,
      right: false,
      space: false,
    };
  }

  // Method to check if any movement key is pressed
  public isMovementKeyPressed(): boolean {
    return this.inputState.up || this.inputState.down || this.inputState.left || this.inputState.right;
  }

  // Method to get the primary movement direction
  public getPrimaryDirection(): "up" | "down" | "left" | "right" | null {
    if (this.inputState.up) return "up";
    if (this.inputState.down) return "down";
    if (this.inputState.left) return "left";
    if (this.inputState.right) return "right";
    return null;
  }
}
