"use client";

import { useState, useEffect } from "react";

interface GameStatsProps {
  score: number;
  gameState: string;
  isVisible: boolean;
}

export function GameStats({ score, gameState, isVisible }: GameStatsProps) {
  const [stats, setStats] = useState({
    totalGames: 0,
    highScore: 0,
    totalBombsPlaced: 0,
    totalWallsDestroyed: 0,
    totalPowerUpsCollected: 0,
    playTime: 0,
  });

  const [sessionStartTime, setSessionStartTime] = useState<number | null>(null);

  useEffect(() => {
    // 从localStorage加载统计数据
    const savedStats = localStorage.getItem("bomberman-stats");
    if (savedStats) {
      setStats(JSON.parse(savedStats));
    }
  }, []);

  useEffect(() => {
    if (gameState === "playing" && !sessionStartTime) {
      setSessionStartTime(Date.now());
    } else if (gameState === "gameOver" && sessionStartTime) {
      const sessionTime = Math.floor((Date.now() - sessionStartTime) / 1000);
      setStats((prev) => ({
        ...prev,
        totalGames: prev.totalGames + 1,
        highScore: Math.max(prev.highScore, score),
        playTime: prev.playTime + sessionTime,
      }));
      setSessionStartTime(null);
    }
  }, [gameState, score, sessionStartTime]);

  useEffect(() => {
    // 保存统计数据到localStorage
    localStorage.setItem("bomberman-stats", JSON.stringify(stats));
  }, [stats]);

  if (!isVisible) return null;

  return (
    <div className="bg-opacity-75 fixed top-20 left-4 z-10 max-w-64 rounded-lg bg-black p-4 font-mono text-sm text-white">
      <h3 className="mb-3 text-center text-lg font-bold">游戏统计</h3>

      <div className="space-y-2">
        <div className="flex justify-between">
          <span>当前分数:</span>
          <span className="font-bold text-yellow-400">{score}</span>
        </div>

        <div className="flex justify-between">
          <span>最高分数:</span>
          <span className="text-green-400">{stats.highScore}</span>
        </div>

        <div className="flex justify-between">
          <span>游戏次数:</span>
          <span>{stats.totalGames}</span>
        </div>

        <div className="flex justify-between">
          <span>总游戏时间:</span>
          <span>
            {Math.floor(stats.playTime / 60)}分{stats.playTime % 60}秒
          </span>
        </div>

        <div className="flex justify-between">
          <span>放置炸弹:</span>
          <span>{stats.totalBombsPlaced}</span>
        </div>

        <div className="flex justify-between">
          <span>摧毁墙壁:</span>
          <span>{stats.totalWallsDestroyed}</span>
        </div>

        <div className="flex justify-between">
          <span>收集道具:</span>
          <span>{stats.totalPowerUpsCollected}</span>
        </div>
      </div>

      {/* 成就系统 */}
      <div className="mt-4 border-t border-gray-600 pt-3">
        <h4 className="mb-2 text-sm font-bold">成就</h4>
        <div className="space-y-1 text-xs">
          {stats.highScore >= 100 && <div className="text-yellow-400">🏆 新手爆破手 (100分)</div>}
          {stats.highScore >= 500 && <div className="text-yellow-400">💎 爆破专家 (500分)</div>}
          {stats.highScore >= 1000 && <div className="text-yellow-400">👑 爆破大师 (1000分)</div>}
          {stats.totalGames >= 10 && <div className="text-blue-400">🎮 游戏爱好者 (10局)</div>}
          {stats.totalGames >= 50 && <div className="text-blue-400">🎯 游戏达人 (50局)</div>}
          {stats.playTime >= 3600 && <div className="text-green-400">⏰ 时间守护者 (1小时)</div>}
        </div>
      </div>
    </div>
  );
}
