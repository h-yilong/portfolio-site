import {
  GameState,
  Direction,
  TileType,
  Position,
  Tile,
  Player,
  Bomb,
  Explosion,
  PowerUp,
  GameConfig,
  GameCallbacks,
  InputState,
} from "./types";
import { MapGenerator } from "./MapGenerator";
import { Renderer } from "./Renderer";
import { InputManager } from "./InputManager";
import { CollisionManager } from "./CollisionManager";
import { BombPool, ExplosionPool, PowerUpPool } from "./ObjectPool";

export class GameEngine {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private callbacks: GameCallbacks;

  // Game state
  private gameState: GameState = "menu";
  private score: number = 0;
  private lastTime: number = 0;
  private animationId: number | null = null;

  // Game objects
  private player: Player;
  private map: Tile[][];
  private bombs: Bomb[] = [];
  private explosions: Explosion[] = [];
  private powerUps: PowerUp[] = [];

  // Managers
  private mapGenerator: MapGenerator;
  private renderer: Renderer;
  private inputManager: InputManager;
  private collisionManager: CollisionManager;
  private bombPool: BombPool;
  private explosionPool: ExplosionPool;
  private powerUpPool: PowerUpPool;

  // Configuration
  private config: GameConfig = {
    canvasWidth: 800,
    canvasHeight: 600,
    tileSize: 40,
    playerSpeed: 200, // pixels per second
    bombTimer: 2000, // milliseconds
    explosionTimer: 1000, // milliseconds
    powerUpChance: 0.3,
  };

  constructor(canvas: HTMLCanvasElement, callbacks: GameCallbacks) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d")!;
    this.callbacks = callbacks;

    // Initialize managers
    this.mapGenerator = new MapGenerator(this.config);
    this.renderer = new Renderer(this.ctx, this.config);
    this.inputManager = new InputManager();
    this.collisionManager = new CollisionManager(this.config);
    this.bombPool = new BombPool();
    this.explosionPool = new ExplosionPool();
    this.powerUpPool = new PowerUpPool();

    // Initialize player
    this.player = this.createPlayer();

    // Initialize map
    this.map = this.mapGenerator.generateMap();
  }

  public init(): void {
    this.inputManager.init();
    this.renderer.init();
    this.setGameState("menu");
  }

  public startGame(): void {
    this.resetGame();
    this.setGameState("playing");
    this.startGameLoop();
  }

  public pauseGame(): void {
    if (this.gameState === "playing") {
      this.setGameState("paused");
      this.stopGameLoop();
    }
  }

  public resumeGame(): void {
    if (this.gameState === "paused") {
      this.setGameState("playing");
      this.startGameLoop();
    }
  }

  public restartGame(): void {
    this.resetGame();
    this.setGameState("playing");
    this.startGameLoop();
  }

  public destroy(): void {
    this.stopGameLoop();
    this.inputManager.destroy();
  }

  private resetGame(): void {
    this.score = 0;
    this.player = this.createPlayer();
    this.map = this.mapGenerator.generateMap();
    this.bombs = [];
    this.explosions = [];
    this.powerUps = [];
    this.callbacks.onScoreChange(this.score);
  }

  private createPlayer(): Player {
    return {
      id: "player",
      x: 1,
      y: 1,
      direction: "down",
      bombs: 0,
      maxBombs: 1,
      bombRange: 1,
      speed: this.config.playerSpeed,
      isAlive: true,
      lastMoveTime: 0,
    };
  }

  private setGameState(state: GameState): void {
    this.gameState = state;
    this.callbacks.onStateChange(state);
  }

  private startGameLoop(): void {
    if (this.animationId) return;

    const gameLoop = (currentTime: number) => {
      if (this.gameState !== "playing") return;

      const deltaTime = currentTime - this.lastTime;
      this.lastTime = currentTime;

      this.update(deltaTime);
      this.render();

      this.animationId = requestAnimationFrame(gameLoop);
    };

    this.lastTime = performance.now();
    this.animationId = requestAnimationFrame(gameLoop);
  }

  private stopGameLoop(): void {
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }
  }

  private update(deltaTime: number): void {
    this.handleInput(deltaTime);
    this.updateBombs(deltaTime);
    this.updateExplosions(deltaTime);
    this.checkCollisions();
    this.checkGameOver();
  }

  private handleInput(deltaTime: number): void {
    const input = this.inputManager.getInput();

    // Handle movement
    if (input.up || input.down || input.left || input.right) {
      this.movePlayer(input, deltaTime);
    }

    // Handle bomb placement
    if (input.space) {
      this.placeBomb();
    }
  }

  private movePlayer(input: InputState, deltaTime: number): void {
    const currentTime = performance.now();
    const moveInterval = 1000 / (this.player.speed / this.config.tileSize);

    if (currentTime - this.player.lastMoveTime < moveInterval) {
      return;
    }

    let newX = this.player.x;
    let newY = this.player.y;
    let newDirection: Direction = this.player.direction;

    if (input.up) {
      newY--;
      newDirection = "up";
    } else if (input.down) {
      newY++;
      newDirection = "down";
    } else if (input.left) {
      newX--;
      newDirection = "left";
    } else if (input.right) {
      newX++;
      newDirection = "right";
    }

    if (this.canMoveTo(newX, newY)) {
      this.player.x = newX;
      this.player.y = newY;
      this.player.direction = newDirection;
      this.player.lastMoveTime = currentTime;
    }
  }

  private canMoveTo(x: number, y: number): boolean {
    if (x < 0 || y < 0 || x >= this.map[0].length || y >= this.map.length) {
      return false;
    }

    const tile = this.map[y][x];
    return tile.type === "empty" || tile.type === "powerup";
  }

  private placeBomb(): void {
    if (this.player.bombs >= this.player.maxBombs) return;

    const bombX = Math.floor(this.player.x);
    const bombY = Math.floor(this.player.y);

    // Check if there's already a bomb at this position
    if (this.bombs.some((bomb) => bomb.x === bombX && bomb.y === bombY)) {
      return;
    }

    const bomb: Bomb = {
      id: `bomb_${Date.now()}_${Math.random()}`,
      x: bombX,
      y: bombY,
      timer: this.config.bombTimer,
      range: this.player.bombRange,
      owner: this.player.id,
      placedTime: performance.now(),
    };

    this.bombs.push(bomb);
    this.player.bombs++;
  }

  private updateBombs(deltaTime: number): void {
    for (let i = this.bombs.length - 1; i >= 0; i--) {
      const bomb = this.bombs[i];
      bomb.timer -= deltaTime;

      if (bomb.timer <= 0) {
        this.explodeBomb(bomb);
        this.bombs.splice(i, 1);
        this.player.bombs--;
      }
    }
  }

  private explodeBomb(bomb: Bomb): void {
    const directions: Direction[] = ["up", "down", "left", "right"];

    // Center explosion
    this.createExplosion(bomb.x, bomb.y, "center");

    // Directional explosions
    for (const direction of directions) {
      for (let i = 1; i <= bomb.range; i++) {
        const x = bomb.x + (direction === "left" ? -i : direction === "right" ? i : 0);
        const y = bomb.y + (direction === "up" ? -i : direction === "down" ? i : 0);

        if (this.isValidPosition(x, y)) {
          const tile = this.map[y][x];

          if (tile.type === "wall") {
            break; // Stop explosion at walls
          }

          this.createExplosion(x, y, direction);

          if (tile.type === "breakable") {
            this.breakTile(x, y);
            break; // Stop explosion at breakable walls
          }
        } else {
          break; // Stop explosion at map boundaries
        }
      }
    }
  }

  private createExplosion(x: number, y: number, direction: Direction | "center"): void {
    const explosion: Explosion = {
      id: `explosion_${Date.now()}_${Math.random()}`,
      x,
      y,
      timer: this.config.explosionTimer,
      range: 1,
      direction,
    };

    this.explosions.push(explosion);
  }

  private breakTile(x: number, y: number): void {
    const tile = this.map[y][x];

    // Chance to spawn powerup
    if (Math.random() < this.config.powerUpChance) {
      const powerUpTypes: ("bomb" | "range" | "speed")[] = ["bomb", "range", "speed"];
      const randomType = powerUpTypes[Math.floor(Math.random() * powerUpTypes.length)];

      const powerUp: PowerUp = {
        id: `powerup_${Date.now()}_${Math.random()}`,
        x,
        y,
        type: randomType,
      };

      this.powerUps.push(powerUp);
      tile.type = "powerup";
      tile.powerupType = randomType;
    } else {
      tile.type = "empty";
    }

    this.score += 10;
    this.callbacks.onScoreChange(this.score);
  }

  private updateExplosions(deltaTime: number): void {
    for (let i = this.explosions.length - 1; i >= 0; i--) {
      const explosion = this.explosions[i];
      explosion.timer -= deltaTime;

      if (explosion.timer <= 0) {
        this.explosions.splice(i, 1);
      }
    }
  }

  private checkCollisions(): void {
    // Check player collision with explosions
    const playerTileX = Math.floor(this.player.x);
    const playerTileY = Math.floor(this.player.y);

    const isInExplosion = this.explosions.some(
      (explosion) => explosion.x === playerTileX && explosion.y === playerTileY,
    );

    if (isInExplosion && this.player.isAlive) {
      this.player.isAlive = false;
    }

    // Check player collision with powerups
    for (let i = this.powerUps.length - 1; i >= 0; i--) {
      const powerUp = this.powerUps[i];

      if (Math.floor(this.player.x) === powerUp.x && Math.floor(this.player.y) === powerUp.y) {
        this.collectPowerUp(powerUp);
        this.powerUps.splice(i, 1);
        this.map[powerUp.y][powerUp.x].type = "empty";
      }
    }
  }

  private collectPowerUp(powerUp: PowerUp): void {
    switch (powerUp.type) {
      case "bomb":
        this.player.maxBombs++;
        this.player.bombs++;
        break;
      case "range":
        this.player.bombRange++;
        break;
      case "speed":
        this.player.speed += 50;
        break;
    }

    this.score += 50;
    this.callbacks.onScoreChange(this.score);
  }

  private checkGameOver(): void {
    if (!this.player.isAlive) {
      this.setGameState("gameOver");
      this.stopGameLoop();
    }
  }

  private isValidPosition(x: number, y: number): boolean {
    return x >= 0 && y >= 0 && x < this.map[0].length && y < this.map.length;
  }

  private render(): void {
    this.renderer.clear();
    this.renderer.renderMap(this.map);
    this.renderer.renderPlayer(this.player);
    this.renderer.renderBombs(this.bombs);
    this.renderer.renderExplosions(this.explosions);
    this.renderer.renderPowerUps(this.powerUps);
  }
}
