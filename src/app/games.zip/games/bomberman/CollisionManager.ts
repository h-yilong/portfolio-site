import { GameConfig, Tile, Position } from "./types";

export class CollisionManager {
  private config: GameConfig;

  constructor(config: GameConfig) {
    this.config = config;
  }

  public isPositionValid(x: number, y: number, map: Tile[][]): boolean {
    if (x < 0 || y < 0 || x >= map[0].length || y >= map.length) {
      return false;
    }
    return true;
  }

  public canMoveTo(x: number, y: number, map: Tile[][]): boolean {
    if (!this.isPositionValid(x, y, map)) {
      return false;
    }

    const tile = map[y][x];
    return tile.type === "empty" || tile.type === "powerup";
  }

  public isPositionInExplosion(x: number, y: number, explosions: any[]): boolean {
    return explosions.some((explosion) => explosion.x === x && explosion.y === y);
  }

  public isPositionOccupiedByBomb(x: number, y: number, bombs: any[]): boolean {
    return bombs.some((bomb) => bomb.x === x && bomb.y === y);
  }

  public getCollidingBombs(x: number, y: number, bombs: any[]): any[] {
    return bombs.filter((bomb) => bomb.x === x && bomb.y === y);
  }

  public getCollidingPowerUps(x: number, y: number, powerUps: any[]): any[] {
    return powerUps.filter((powerUp) => powerUp.x === x && powerUp.y === y);
  }

  public isPositionInExplosionRange(x: number, y: number, explosions: any[]): boolean {
    return explosions.some((explosion) => {
      const distance = Math.abs(explosion.x - x) + Math.abs(explosion.y - y);
      return distance <= explosion.range;
    });
  }

  public getExplosionRange(x: number, y: number, range: number, map: Tile[][]): Position[] {
    const positions: Position[] = [];
    const directions = [
      { dx: 0, dy: -1 }, // up
      { dx: 0, dy: 1 }, // down
      { dx: -1, dy: 0 }, // left
      { dx: 1, dy: 0 }, // right
    ];

    // Add center position
    positions.push({ x, y });

    // Add positions in each direction
    for (const direction of directions) {
      for (let i = 1; i <= range; i++) {
        const newX = x + direction.dx * i;
        const newY = y + direction.dy * i;

        if (!this.isPositionValid(newX, newY, map)) {
          break; // Stop at map boundaries
        }

        const tile = map[newY][newX];
        positions.push({ x: newX, y: newY });

        if (tile.type === "wall") {
          break; // Stop at walls
        }

        if (tile.type === "breakable") {
          break; // Stop at breakable walls
        }
      }
    }

    return positions;
  }

  public isPlayerInExplosion(playerX: number, playerY: number, explosions: any[]): boolean {
    const playerTileX = Math.floor(playerX);
    const playerTileY = Math.floor(playerY);

    return explosions.some((explosion) => explosion.x === playerTileX && explosion.y === playerTileY);
  }

  public getSafePositions(map: Tile[][], explosions: any[]): Position[] {
    const safePositions: Position[] = [];

    for (let y = 0; y < map.length; y++) {
      for (let x = 0; x < map[y].length; x++) {
        if (this.canMoveTo(x, y, map) && !this.isPositionInExplosion(x, y, explosions)) {
          safePositions.push({ x, y });
        }
      }
    }

    return safePositions;
  }

  public isPathClear(startX: number, startY: number, endX: number, endY: number, map: Tile[][]): boolean {
    const dx = Math.sign(endX - startX);
    const dy = Math.sign(endY - startY);

    let currentX = startX;
    let currentY = startY;

    while (currentX !== endX || currentY !== endY) {
      if (dx !== 0) {
        currentX += dx;
      }
      if (dy !== 0) {
        currentY += dy;
      }

      if (!this.canMoveTo(currentX, currentY, map)) {
        return false;
      }
    }

    return true;
  }

  public getNearestSafePosition(x: number, y: number, map: Tile[][], explosions: any[]): Position | null {
    const safePositions = this.getSafePositions(map, explosions);

    if (safePositions.length === 0) {
      return null;
    }

    let nearestPosition = safePositions[0];
    let minDistance = this.getDistance(x, y, nearestPosition.x, nearestPosition.y);

    for (const position of safePositions) {
      const distance = this.getDistance(x, y, position.x, position.y);
      if (distance < minDistance) {
        minDistance = distance;
        nearestPosition = position;
      }
    }

    return nearestPosition;
  }

  private getDistance(x1: number, y1: number, x2: number, y2: number): number {
    return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
  }
}
