import { GameConfig, Tile, TileType } from "./types";

export class MapGenerator {
  private config: GameConfig;

  constructor(config: GameConfig) {
    this.config = config;
  }

  public generateMap(): Tile[][] {
    const mapWidth = Math.floor(this.config.canvasWidth / this.config.tileSize);
    const mapHeight = Math.floor(this.config.canvasHeight / this.config.tileSize);

    const map: Tile[][] = [];

    // Initialize empty map
    for (let y = 0; y < mapHeight; y++) {
      map[y] = [];
      for (let x = 0; x < mapWidth; x++) {
        map[y][x] = {
          type: "empty",
          x,
          y,
        };
      }
    }

    // Add walls around the edges
    this.addBorderWalls(map);

    // Add random breakable walls
    this.addBreakableWalls(map);

    // Ensure player starting area is clear
    this.clearStartingArea(map);

    // Ensure map is traversable
    this.ensureTraversability(map);

    return map;
  }

  private addBorderWalls(map: Tile[][]): void {
    const height = map.length;
    const width = map[0].length;

    // Top and bottom walls
    for (let x = 0; x < width; x++) {
      map[0][x].type = "wall";
      map[height - 1][x].type = "wall";
    }

    // Left and right walls
    for (let y = 0; y < height; y++) {
      map[y][0].type = "wall";
      map[y][width - 1].type = "wall";
    }
  }

  private addBreakableWalls(map: Tile[][]): void {
    const height = map.length;
    const width = map[0].length;

    for (let y = 1; y < height - 1; y++) {
      for (let x = 1; x < width - 1; x++) {
        // Skip player starting area
        if ((x === 1 && y === 1) || (x === 2 && y === 1) || (x === 1 && y === 2)) {
          continue;
        }

        // Add breakable walls with some randomness
        if (Math.random() < 0.4) {
          map[y][x].type = "breakable";
          map[y][x].breakable = true;
        }
      }
    }
  }

  private clearStartingArea(map: Tile[][]): void {
    // Clear 3x3 area around player start position
    for (let y = 0; y < 3; y++) {
      for (let x = 0; x < 3; x++) {
        if (map[y] && map[y][x]) {
          map[y][x].type = "empty";
        }
      }
    }
  }

  private ensureTraversability(map: Tile[][]): void {
    const height = map.length;
    const width = map[0].length;

    // Create some pathways by removing some breakable walls
    for (let y = 1; y < height - 1; y += 2) {
      for (let x = 1; x < width - 1; x += 2) {
        if (map[y][x].type === "breakable") {
          // Randomly remove some breakable walls to create paths
          if (Math.random() < 0.3) {
            map[y][x].type = "empty";
          }
        }
      }
    }

    // Ensure there are some open areas
    this.createOpenAreas(map);
  }

  private createOpenAreas(map: Tile[][]): void {
    const height = map.length;
    const width = map[0].length;

    // Create a few open areas
    for (let i = 0; i < 3; i++) {
      const centerX = Math.floor(Math.random() * (width - 4)) + 2;
      const centerY = Math.floor(Math.random() * (height - 4)) + 2;

      // Clear 3x3 area around center
      for (let y = centerY - 1; y <= centerY + 1; y++) {
        for (let x = centerX - 1; x <= centerX + 1; x++) {
          if (y > 0 && y < height - 1 && x > 0 && x < width - 1) {
            map[y][x].type = "empty";
          }
        }
      }
    }
  }
}
