"use client";

import { useEffect, useRef, useState } from "react";
import { GameEngine } from "./GameEngine";
import { GameState } from "./types";
import { GameDemo } from "./demo";
import { PerformanceMonitor } from "./PerformanceMonitor";
import { GameStats } from "./GameStats";

export default function BombermanGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameEngineRef = useRef<GameEngine | null>(null);
  const [gameState, setGameState] = useState<GameState>("menu");
  const [score, setScore] = useState(0);
  const [showDemo, setShowDemo] = useState(false);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const gameEngine = new GameEngine(canvas, {
      onStateChange: setGameState,
      onScoreChange: setScore,
    });

    gameEngineRef.current = gameEngine;
    gameEngine.init();

    return () => {
      gameEngine.destroy();
    };
  }, []);

  const startGame = () => {
    gameEngineRef.current?.startGame();
  };

  const pauseGame = () => {
    gameEngineRef.current?.pauseGame();
  };

  const resumeGame = () => {
    gameEngineRef.current?.resumeGame();
  };

  const restartGame = () => {
    gameEngineRef.current?.restartGame();
  };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 p-4">
      <div className="mb-6 text-center">
        <h1 className="mb-2 font-mono text-5xl font-bold text-white">BOMBERMAN</h1>
        <p className="text-lg text-gray-300">Classic Arcade Game</p>
      </div>

      {/* Game Canvas */}
      <div className="relative">
        <canvas
          ref={canvasRef}
          className="rounded-lg border-4 border-white bg-black shadow-2xl"
          width={800}
          height={600}
        />

        {/* Overlay UI */}
        {gameState === "menu" && (
          <div className="bg-opacity-80 absolute inset-0 flex items-center justify-center rounded-lg bg-black">
            <div className="text-center">
              <h2 className="mb-4 text-3xl font-bold text-white">Welcome to Bomberman!</h2>
              <div className="mx-auto max-w-md space-y-4 text-left text-gray-300">
                <div className="rounded-lg bg-gray-800 p-4">
                  <h3 className="mb-2 text-xl font-semibold text-white">Controls:</h3>
                  <ul className="list-disc space-y-1 pl-5 text-sm">
                    <li>Arrow Keys: Move</li>
                    <li>Spacebar: Place Bomb</li>
                    <li>P: Pause/Resume</li>
                    <li>R: Restart</li>
                  </ul>
                </div>
                <div className="space-y-3">
                  <button
                    onClick={startGame}
                    className="w-full rounded-lg bg-red-600 px-6 py-3 font-bold text-white transition-colors hover:bg-red-700"
                  >
                    Start Game
                  </button>
                  <button
                    onClick={() => setShowDemo(true)}
                    className="w-full rounded-lg bg-blue-600 px-6 py-3 font-bold text-white transition-colors hover:bg-blue-700"
                  >
                    Try Demo
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {gameState === "paused" && (
          <div className="bg-opacity-60 absolute inset-0 flex items-center justify-center rounded-lg bg-black">
            <div className="text-center">
              <h2 className="mb-4 text-3xl font-bold text-white">Game Paused</h2>
              <div className="space-x-4">
                <button
                  onClick={resumeGame}
                  className="rounded bg-green-600 px-4 py-2 font-bold text-white hover:bg-green-700"
                >
                  Resume
                </button>
                <button
                  onClick={restartGame}
                  className="rounded bg-red-600 px-4 py-2 font-bold text-white hover:bg-red-700"
                >
                  Restart
                </button>
              </div>
            </div>
          </div>
        )}

        {gameState === "gameOver" && (
          <div className="bg-opacity-80 absolute inset-0 flex items-center justify-center rounded-lg bg-black">
            <div className="text-center">
              <h2 className="mb-4 text-3xl font-bold text-white">Game Over!</h2>
              <p className="mb-4 text-xl text-gray-300">Final Score: {score}</p>
              <button
                onClick={restartGame}
                className="rounded bg-red-600 px-4 py-2 font-bold text-white hover:bg-red-700"
              >
                Play Again
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Game Info */}
      <div className="mt-6 text-center text-white">
        <div className="flex space-x-8 text-lg">
          <div>
            <span className="text-gray-400">Score: </span>
            <span className="font-bold">{score}</span>
          </div>
          <div>
            <span className="text-gray-400">State: </span>
            <span className="font-bold capitalize">{gameState}</span>
          </div>
        </div>
      </div>

      {/* Controls Info */}
      <div className="mt-4 text-sm text-gray-400">
        <p>Press P to pause, R to restart</p>
      </div>

      {/* Demo Modal */}
      {showDemo && <GameDemo onClose={() => setShowDemo(false)} />}

      {/* Performance Monitor */}
      <PerformanceMonitor isActive={gameState === "playing"} />

      {/* Game Stats */}
      <GameStats score={score} gameState={gameState} isVisible={gameState === "playing" || gameState === "gameOver"} />
    </div>
  );
}
