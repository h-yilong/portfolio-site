import { GameConfig, Tile, Player, Bomb, Explosion, PowerUp, Direction } from "./types";
import wall from "./wall.svg";

export class Renderer {
  private ctx: CanvasRenderingContext2D;
  private config: GameConfig;
  private tileCache: Map<string, ImageBitmap> = new Map();
  private colors = {
    empty: "#0c7",
    wall: "#4a4a4a",
    breakable: "#8B4513",
    bomb: "#000000",
    explosion: "#FF4500",
    player: "#00FF00",
    powerup: {
      bomb: "#FFD700",
      range: "#FF6347",
      speed: "#00CED1",
    },
  };

  private headUpImage: HTMLImageElement | null = null;
  private headDownImage: HTMLImageElement | null = null;
  private headLeftImage: HTMLImageElement | null = null;
  private headRightImage: HTMLImageElement | null = null;
  private breakableImage: HTMLImageElement | null = null;
  private bombImage: HTMLImageElement | null = null;
  private bombImage2: HTMLImageElement | null = null;

  constructor(ctx: CanvasRenderingContext2D, config: GameConfig) {
    this.ctx = ctx;
    this.config = config;
    this.headUpImage = new window.Image();
    this.headUpImage.src = "/assets/images/head-up.svg";
    this.headDownImage = new window.Image();
    this.headDownImage.src = "/assets/images/head-down.svg";
    this.headLeftImage = new window.Image();
    this.headLeftImage.src = "/assets/images/head-left.svg";
    this.headRightImage = new window.Image();
    this.headRightImage.src = "/assets/images/head-right.svg";
    this.breakableImage = new window.Image();
    this.breakableImage.src = "/assets/images/breakable.svg";
    this.bombImage = new window.Image();
    this.bombImage.src = "/assets/images/bomb.svg";
    this.bombImage2 = new window.Image();
    this.bombImage2.src = "/assets/images/bomb2.svg";
  }

  public init(): void {
    // Set canvas properties for better performance
    this.ctx.imageSmoothingEnabled = false;
    this.ctx.textBaseline = "top";
  }

  public clear(): void {
    this.ctx.fillStyle = this.colors.empty;
    this.ctx.fillRect(0, 0, this.config.canvasWidth, this.config.canvasHeight);
  }

  public renderMap(map: Tile[][]): void {
    const tileSize = this.config.tileSize;

    for (let y = 0; y < map.length; y++) {
      for (let x = 0; x < map[y].length; x++) {
        const tile = map[y][x];
        const screenX = x * tileSize;
        const screenY = y * tileSize;

        this.renderTile(tile, screenX, screenY, tileSize);
      }
    }
  }

  private renderTile(tile: Tile, x: number, y: number, size: number): void {
    switch (tile.type) {
      case "empty":
        // Already cleared by background
        break;
      case "wall":
        this.ctx.fillStyle = this.colors.wall;
        this.ctx.fillRect(x, y, size, size);
        this.drawWallPattern(x, y, size);
        break;
      case "breakable":
        this.ctx.fillStyle = this.colors.breakable;
        this.ctx.fillRect(x, y, size, size);
        this.drawBreakablePattern(x, y, size);
        break;
      case "powerup":
        this.renderPowerUp(tile, x, y, size);
        break;
    }
  }

  private wallImage: HTMLImageElement | null = null;

  private loadWallImage(): void {
    if (this.wallImage) return;
    this.wallImage = new window.Image();
    this.wallImage.src = wall.src;
    // this.wallImage.src = "/assets/images/bomberman-head.svg";
    // this.wallImage.src = require("./wall.svg").default || require("./wall.svg");
  }

  private drawWallPattern(x: number, y: number, size: number): void {
    this.loadWallImage();
    if (this.wallImage && this.wallImage.complete) {
      this.ctx.drawImage(this.wallImage, x, y, size, size);
    } else if (this.wallImage) {
      // If image is not loaded yet, draw after it loads
      this.wallImage.onload = () => {
        this.ctx.drawImage(this.wallImage!, x, y, size, size);
      };
    }
  }

  private drawBreakablePattern(x: number, y: number, size: number): void {
    if (this.breakableImage) {
      this.ctx.drawImage(this.breakableImage, x, y, size, size);
    } else {
      this.ctx.strokeStyle = "#654321";
      this.ctx.lineWidth = 1;

      // Draw wood pattern
      for (let i = 0; i < size; i += 4) {
        this.ctx.beginPath();
        this.ctx.moveTo(x, y + i);
        this.ctx.lineTo(x + size, y + i);
        this.ctx.stroke();
      }
    }
  }

  public renderPlayer(player: Player): void {
    if (!player.isAlive) return;

    const tileSize = this.config.tileSize;
    const x = player.x * tileSize;
    const y = player.y * tileSize;
    const size = tileSize * 0.8;
    const offset = (tileSize - size) / 2;

    // // Player body
    // this.ctx.fillStyle = this.colors.player;
    // this.ctx.fillRect(x + offset, y + offset, size, size);

    // Player direction indicator
    this.ctx.fillStyle = "#00CC00";
    const indicatorSize = size * 0.3;
    const indicatorOffset = (size - indicatorSize) / 2;

    switch (player.direction) {
      case "up":
        this.ctx.drawImage(this.headUpImage!, x, y, tileSize, tileSize);
        break;
      case "down":
        this.ctx.drawImage(this.headDownImage!, x, y, tileSize, tileSize);
        break;
      case "left":
        this.ctx.drawImage(this.headLeftImage!, x, y, tileSize, tileSize);
        // this.ctx.fillRect(x + offset, y + offset + indicatorOffset, indicatorSize / 2, indicatorSize);
        break;
      case "right":
        this.ctx.drawImage(this.headRightImage!, x, y, tileSize, tileSize);
        break;
      default:
        this.ctx.drawImage(this.headUpImage!, x, y, tileSize, tileSize);
        break;
    }
  }

  public renderBombs(bombs: Bomb[]): void {
    const tileSize = this.config.tileSize;

    bombs.forEach((bomb) => {
      const x = bomb.x * tileSize;
      const y = bomb.y * tileSize;
      const size = tileSize * 0.7;
      const offset = (tileSize - size) / 2;

      // Bomb body
      // this.ctx.fillStyle = this.colors.bomb;
      // this.ctx.beginPath();
      // this.ctx.arc(x + tileSize / 2, y + tileSize / 2, size / 2, 0, Math.PI * 2);
      // this.ctx.fill();
      const bombImage = bomb.timer % 1000 > 500 ? this.bombImage2 : this.bombImage;
      this.ctx.drawImage(bombImage!, x + offset, y + offset, size, size);

      // Bomb fuse
      this.ctx.strokeStyle = "#FFD700";
      this.ctx.lineWidth = 2;
      this.ctx.beginPath();
      this.ctx.moveTo(x + tileSize / 2, y + offset);
      this.ctx.lineTo(x + tileSize / 2, y + offset - 8);
      this.ctx.stroke();

      // Bomb timer indicator (from green(120) to red(0))
      const progress = bomb.timer / 2000; // Assuming 2000ms timer
      this.ctx.fillStyle = `hsl(${progress * 120}, 100%, 50%)`;
      this.ctx.fillRect(x + offset, y + tileSize - 4, size * progress, 4);
    });
  }

  public renderExplosions(explosions: Explosion[]): void {
    const tileSize = this.config.tileSize;

    explosions.forEach((explosion) => {
      const x = explosion.x * tileSize;
      const y = explosion.y * tileSize;
      const progress = 1 - explosion.timer / 1000; // Assuming 1000ms timer
      const alpha = 1 - progress;

      this.ctx.save();
      this.ctx.globalAlpha = alpha;

      if (explosion.direction === "center") {
        // Center explosion
        this.ctx.fillStyle = this.colors.explosion;
        this.ctx.fillRect(x, y, tileSize, tileSize);
      } else {
        // Directional explosion
        this.ctx.fillStyle = this.colors.explosion;
        this.ctx.fillRect(x, y, tileSize, tileSize);

        // Add directional flare
        this.ctx.fillStyle = "#FFA500";
        const flareSize = tileSize * 0.3;
        const flareOffset = (tileSize - flareSize) / 2;

        switch (explosion.direction) {
          case "up":
            this.ctx.fillRect(x + flareOffset, y - flareSize, flareSize, flareSize);
            break;
          case "down":
            this.ctx.fillRect(x + flareOffset, y + tileSize, flareSize, flareSize);
            break;
          case "left":
            this.ctx.fillRect(x - flareSize, y + flareOffset, flareSize, flareSize);
            break;
          case "right":
            this.ctx.fillRect(x + tileSize, y + flareOffset, flareSize, flareSize);
            break;
        }
      }

      this.ctx.restore();
    });
  }

  public renderPowerUps(powerUps: PowerUp[]): void {
    const tileSize = this.config.tileSize;

    powerUps.forEach((powerUp) => {
      const x = powerUp.x * tileSize;
      const y = powerUp.y * tileSize;
      const size = tileSize * 0.6;
      const offset = (tileSize - size) / 2;

      // Power-up background
      this.ctx.fillStyle = this.colors.powerup[powerUp.type];
      this.ctx.fillRect(x + offset, y + offset, size, size);

      // Power-up symbol
      this.ctx.fillStyle = "#FFFFFF";
      this.ctx.font = `${size * 0.5}px Arial`;
      this.ctx.textAlign = "center";

      let symbol = "";
      switch (powerUp.type) {
        case "bomb":
          symbol = "💣";
          break;
        case "range":
          symbol = "🔥";
          break;
        case "speed":
          symbol = "⚡";
          break;
      }

      this.ctx.fillText(symbol, x + tileSize / 2, y + tileSize / 2 - size * 0.25);
    });
  }

  private renderPowerUp(tile: Tile, x: number, y: number, size: number): void {
    if (!tile.powerupType) return;

    const powerUpSize = size * 0.6;
    const offset = (size - powerUpSize) / 2;

    // Power-up background
    this.ctx.fillStyle = this.colors.powerup[tile.powerupType];
    this.ctx.fillRect(x + offset, y + offset, powerUpSize, powerUpSize);

    // Power-up symbol
    this.ctx.fillStyle = "#FFFFFF";
    this.ctx.font = `${powerUpSize * 0.5}px Arial`;
    this.ctx.textAlign = "center";

    let symbol = "";
    switch (tile.powerupType) {
      case "bomb":
        symbol = "💣";
        break;
      case "range":
        symbol = "🔥";
        break;
      case "speed":
        symbol = "⚡";
        break;
    }

    this.ctx.fillText(symbol, x + size / 2, y + size / 2 - powerUpSize * 0.25);
  }
}
