import { describe, it, expect, beforeEach, vi } from "vitest";
import { GameEngine } from "../GameEngine";
import { GameState } from "../types";

// Mock canvas
const createMockCanvas = () => {
  const canvas = document.createElement("canvas");
  const ctx = {
    fillStyle: "",
    strokeStyle: "",
    lineWidth: 0,
    imageSmoothingEnabled: true,
    textBaseline: "",
    globalAlpha: 1,
    fillRect: vi.fn(),
    strokeRect: vi.fn(),
    beginPath: vi.fn(),
    moveTo: vi.fn(),
    lineTo: vi.fn(),
    stroke: vi.fn(),
    arc: vi.fn(),
    fill: vi.fn(),
    save: vi.fn(),
    restore: vi.fn(),
    fillText: vi.fn(),
  };
  canvas.getContext = vi.fn(() => ctx as any);
  return { canvas, ctx };
};

describe("GameEngine", () => {
  let gameEngine: GameEngine;
  let mockCanvas: HTMLCanvasElement;
  let mockCtx: any;

  beforeEach(() => {
    const mock = createMockCanvas();
    mockCanvas = mock.canvas;
    mockCtx = mock.ctx;

    const callbacks = {
      onStateChange: vi.fn(),
      onScoreChange: vi.fn(),
    };

    gameEngine = new GameEngine(mockCanvas, callbacks);
  });

  describe("Initialization", () => {
    it("should initialize with menu state", () => {
      gameEngine.init();
      expect(gameEngine["gameState"]).toBe("menu");
    });

    it("should create a player with correct initial properties", () => {
      const player = gameEngine["createPlayer"]();
      expect(player.x).toBe(1);
      expect(player.y).toBe(1);
      expect(player.isAlive).toBe(true);
      expect(player.bombs).toBe(1);
      expect(player.maxBombs).toBe(1);
      expect(player.bombRange).toBe(1);
    });
  });

  describe("Game State Management", () => {
    it("should start game correctly", () => {
      gameEngine.init();
      gameEngine.startGame();
      expect(gameEngine["gameState"]).toBe("playing");
    });

    it("should pause and resume game", () => {
      gameEngine.init();
      gameEngine.startGame();
      gameEngine.pauseGame();
      expect(gameEngine["gameState"]).toBe("paused");
      gameEngine.resumeGame();
      expect(gameEngine["gameState"]).toBe("playing");
    });

    it("should restart game", () => {
      gameEngine.init();
      gameEngine.startGame();
      gameEngine.restartGame();
      expect(gameEngine["gameState"]).toBe("playing");
      expect(gameEngine["score"]).toBe(0);
    });
  });

  describe("Movement", () => {
    beforeEach(() => {
      gameEngine.init();
      gameEngine.startGame();
    });

    it("should allow movement to empty tiles", () => {
      const canMove = gameEngine["canMoveTo"](2, 1);
      expect(canMove).toBe(true);
    });

    it("should prevent movement to walls", () => {
      const canMove = gameEngine["canMoveTo"](0, 0);
      expect(canMove).toBe(false);
    });

    it("should prevent movement outside map boundaries", () => {
      const canMove = gameEngine["canMoveTo"](-1, 0);
      expect(canMove).toBe(false);
    });
  });

  describe("Bomb Placement", () => {
    beforeEach(() => {
      gameEngine.init();
      gameEngine.startGame();
    });

    it("should place bomb at player position", () => {
      const initialBombCount = gameEngine["bombs"].length;
      gameEngine["placeBomb"]();
      expect(gameEngine["bombs"].length).toBe(initialBombCount + 1);
    });

    it("should not place bomb if player has no bombs left", () => {
      gameEngine["player"].bombs = 0;
      gameEngine["player"].maxBombs = 0;
      const initialBombCount = gameEngine["bombs"].length;
      gameEngine["placeBomb"]();
      expect(gameEngine["bombs"].length).toBe(initialBombCount);
    });
  });

  describe("Collision Detection", () => {
    beforeEach(() => {
      gameEngine.init();
      gameEngine.startGame();
    });

    it("should detect valid positions", () => {
      const isValid = gameEngine["isValidPosition"](1, 1);
      expect(isValid).toBe(true);
    });

    it("should detect invalid positions", () => {
      const isValid = gameEngine["isValidPosition"](-1, -1);
      expect(isValid).toBe(false);
    });
  });
});
