export class ObjectPool<T> {
  private pool: T[] = [];
  private createFn: () => T;
  private resetFn?: (obj: T) => void;
  private maxSize: number;

  constructor(createFn: () => T, resetFn?: (obj: T) => void, maxSize: number = 100) {
    this.createFn = createFn;
    this.resetFn = resetFn;
    this.maxSize = maxSize;
  }

  public get(): T {
    if (this.pool.length > 0) {
      const obj = this.pool.pop()!;
      if (this.resetFn) {
        this.resetFn(obj);
      }
      return obj;
    }
    return this.createFn();
  }

  public release(obj: T): void {
    if (this.pool.length < this.maxSize) {
      if (this.resetFn) {
        this.resetFn(obj);
      }
      this.pool.push(obj);
    }
  }

  public clear(): void {
    this.pool.length = 0;
  }

  public get size(): number {
    return this.pool.length;
  }
}

// Specific object pools for game objects
export class BombPool extends ObjectPool<any> {
  constructor() {
    super(
      () => ({
        id: "",
        x: 0,
        y: 0,
        timer: 0,
        range: 1,
        owner: "",
        placedTime: 0,
      }),
      (bomb) => {
        bomb.id = "";
        bomb.x = 0;
        bomb.y = 0;
        bomb.timer = 0;
        bomb.range = 1;
        bomb.owner = "";
        bomb.placedTime = 0;
      },
    );
  }
}

export class ExplosionPool extends ObjectPool<any> {
  constructor() {
    super(
      () => ({
        id: "",
        x: 0,
        y: 0,
        timer: 0,
        range: 1,
        direction: "center",
      }),
      (explosion) => {
        explosion.id = "";
        explosion.x = 0;
        explosion.y = 0;
        explosion.timer = 0;
        explosion.range = 1;
        explosion.direction = "center";
      },
    );
  }
}

export class PowerUpPool extends ObjectPool<any> {
  constructor() {
    super(
      () => ({
        id: "",
        x: 0,
        y: 0,
        type: "bomb",
      }),
      (powerUp) => {
        powerUp.id = "";
        powerUp.x = 0;
        powerUp.y = 0;
        powerUp.type = "bomb";
      },
    );
  }
}
