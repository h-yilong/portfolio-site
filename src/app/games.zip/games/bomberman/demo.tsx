"use client";

import { useEffect, useRef, useState } from "react";

interface GameDemoProps {
  onClose: () => void;
}

export function GameDemo({ onClose }: GameDemoProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d")!;

    // 游戏配置
    const config = {
      width: 400,
      height: 300,
      tileSize: 20,
      playerSpeed: 100,
    };

    // 游戏状态
    let gameState = {
      player: { x: 1, y: 1, direction: "down" as const },
      map: [] as string[][],
      bombs: [] as any[],
      explosions: [] as any[],
      lastTime: 0,
      animationId: 0,
    };

    // 生成简单地图
    const generateMap = () => {
      const mapWidth = Math.floor(config.width / config.tileSize);
      const mapHeight = Math.floor(config.height / config.tileSize);
      const map: string[][] = [];

      for (let y = 0; y < mapHeight; y++) {
        map[y] = [];
        for (let x = 0; x < mapWidth; x++) {
          if (x === 0 || y === 0 || x === mapWidth - 1 || y === mapHeight - 1) {
            map[y][x] = "wall";
          } else if (Math.random() < 0.3) {
            map[y][x] = "breakable";
          } else {
            map[y][x] = "empty";
          }
        }
      }

      // 确保玩家起始区域是空的
      for (let y = 0; y < 3; y++) {
        for (let x = 0; x < 3; x++) {
          if (map[y] && map[y][x]) {
            map[y][x] = "empty";
          }
        }
      }

      return map;
    };

    // 渲染函数
    const render = () => {
      // 清空画布
      ctx.fillStyle = "#2a2a2a";
      ctx.fillRect(0, 0, config.width, config.height);

      // 渲染地图
      for (let y = 0; y < gameState.map.length; y++) {
        for (let x = 0; x < gameState.map[y].length; x++) {
          const tile = gameState.map[y][x];
          const screenX = x * config.tileSize;
          const screenY = y * config.tileSize;

          switch (tile) {
            case "wall":
              ctx.fillStyle = "#4a4a4a";
              ctx.fillRect(screenX, screenY, config.tileSize, config.tileSize);
              break;
            case "breakable":
              ctx.fillStyle = "#8B4513";
              ctx.fillRect(screenX, screenY, config.tileSize, config.tileSize);
              break;
          }
        }
      }

      // 渲染玩家
      ctx.fillStyle = "#00FF00";
      const playerSize = config.tileSize * 0.8;
      const playerOffset = (config.tileSize - playerSize) / 2;
      ctx.fillRect(
        gameState.player.x * config.tileSize + playerOffset,
        gameState.player.y * config.tileSize + playerOffset,
        playerSize,
        playerSize,
      );

      // 渲染炸弹
      gameState.bombs.forEach((bomb) => {
        ctx.fillStyle = "#000000";
        ctx.beginPath();
        ctx.arc(
          bomb.x * config.tileSize + config.tileSize / 2,
          bomb.y * config.tileSize + config.tileSize / 2,
          config.tileSize * 0.3,
          0,
          Math.PI * 2,
        );
        ctx.fill();
      });

      // 渲染爆炸
      gameState.explosions.forEach((explosion) => {
        ctx.fillStyle = "#FF4500";
        ctx.fillRect(explosion.x * config.tileSize, explosion.y * config.tileSize, config.tileSize, config.tileSize);
      });
    };

    // 游戏循环
    const gameLoop = (currentTime: number) => {
      if (!isPlaying) return;

      const deltaTime = currentTime - gameState.lastTime;
      gameState.lastTime = currentTime;

      // 更新爆炸
      gameState.explosions = gameState.explosions.filter((explosion) => {
        explosion.timer -= deltaTime;
        return explosion.timer > 0;
      });

      // 更新炸弹
      gameState.bombs = gameState.bombs.filter((bomb) => {
        bomb.timer -= deltaTime;
        if (bomb.timer <= 0) {
          // 创建爆炸
          gameState.explosions.push({
            x: bomb.x,
            y: bomb.y,
            timer: 1000,
          });
          return false;
        }
        return true;
      });

      render();
      gameState.animationId = requestAnimationFrame(gameLoop);
    };

    // 输入处理
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPlaying) return;

      let newX = gameState.player.x;
      let newY = gameState.player.y;

      switch (e.code) {
        case "ArrowUp":
        case "KeyW":
          newY--;
          break;
        case "ArrowDown":
        case "KeyS":
          newY++;
          break;
        case "ArrowLeft":
        case "KeyA":
          newX--;
          break;
        case "ArrowRight":
        case "KeyD":
          newX++;
          break;
        case "Space":
          // 放置炸弹
          const bomb = {
            x: gameState.player.x,
            y: gameState.player.y,
            timer: 3000,
          };
          gameState.bombs.push(bomb);
          return;
      }

      // 检查移动是否有效
      if (
        newX >= 0 &&
        newY >= 0 &&
        newX < gameState.map[0].length &&
        newY < gameState.map.length &&
        gameState.map[newY][newX] === "empty"
      ) {
        gameState.player.x = newX;
        gameState.player.y = newY;
      }
    };

    // 开始游戏
    const startGame = () => {
      gameState.map = generateMap();
      gameState.player = { x: 1, y: 1, direction: "down" as const };
      gameState.bombs = [];
      gameState.explosions = [];
      gameState.lastTime = performance.now();
      setIsPlaying(true);
      gameState.animationId = requestAnimationFrame(gameLoop);
    };

    // 停止游戏
    const stopGame = () => {
      setIsPlaying(false);
      if (gameState.animationId) {
        cancelAnimationFrame(gameState.animationId);
      }
    };

    // 事件监听
    document.addEventListener("keydown", handleKeyDown);

    // 自动开始演示
    startGame();

    // 清理函数
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      stopGame();
    };
  }, [isPlaying]);

  return (
    <div className="bg-opacity-75 fixed inset-0 z-50 flex items-center justify-center bg-black">
      <div className="max-w-2xl rounded-lg bg-gray-900 p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-white">Bomberman 游戏演示</h2>
          <button onClick={onClose} className="text-xl text-gray-400 hover:text-white">
            ×
          </button>
        </div>

        <div className="mb-4 text-center">
          <canvas ref={canvasRef} width={400} height={300} className="rounded border-2 border-white" />
        </div>

        <div className="space-y-2 text-sm text-white">
          <p>
            <strong>控制说明：</strong>
          </p>
          <ul className="list-inside list-disc space-y-1">
            <li>方向键或 WASD：移动角色</li>
            <li>空格键：放置炸弹</li>
            <li>炸弹会在3秒后爆炸</li>
            <li>爆炸会持续1秒</li>
          </ul>
        </div>

        <div className="mt-4 text-center">
          <button onClick={onClose} className="rounded bg-red-600 px-4 py-2 text-white hover:bg-red-700">
            关闭演示
          </button>
        </div>
      </div>
    </div>
  );
}
